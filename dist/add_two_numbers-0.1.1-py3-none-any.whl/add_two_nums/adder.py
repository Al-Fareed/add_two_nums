def add_two_nums(a,b):
    print("From Al-Fareed, Sum is  : ")
    return a + b