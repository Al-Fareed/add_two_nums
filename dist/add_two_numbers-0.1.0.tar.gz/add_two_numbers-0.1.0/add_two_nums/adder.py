def add_two_nums(a,b):
    return a + b