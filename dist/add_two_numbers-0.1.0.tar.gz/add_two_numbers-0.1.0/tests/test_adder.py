from add_two_nums.adder import add_two_nums

def test_add_two_numbers():
    result = add_two_nums(3, 4)
    assert result == 7
